# Walkthrough (for me, so I can explain every file)

**Big idea:** an LLM never draws geometry. It fills in a small JSON form (the *spec*). Plain code turns the spec into a 3D shape, and other code checks the shape.

| File | What it does in one line |
|---|---|
| `index.html` | Browser version: edit spec, see 3D preview, run checks, save STL |
| `enclosure.py` | Reads spec, lays parts in a row, builds tray + lid out of boxes, runs checks, writes STL |
| `cq_backend.py` | Same spec, but uses CadQuery (a CAD library) to cut real holes with boolean operations |
| `validate.py` | Opens an STL with trimesh and tells you if it is watertight |
| `llm.py` | Asks Claude to write the spec from a sentence |
| `specs.py` | Checks a spec's shape and compares part sizes with reference modules |
| `pipeline.py` | idea -> spec -> checks -> build, and re-asks the LLM with the problems if something fails |
| `eval/run_eval.py` | Runs 12 ideas through the pipeline; reports first-pass vs after-repair success |
| `coupon.py` | Makes a tolerance test coupon, converts the slot you pick into a clearance, and writes it into a spec |
| `learn/LEARN.md` | Step-by-step lessons to rebuild this from scratch |

## Words to know
- **Mesh / STL:** a shape stored as many triangles.
- **Watertight (manifold):** every edge is shared by exactly two triangles, so there are no gaps. Slicers need this.
- **Boolean operation:** union, cut or intersect two solids (e.g. cutting the USB hole).
- **Parametric:** the shape is computed from numbers (wall, clearance), so changing a number rebuilds it.
- **Clearance:** the small gap between a part and the wall so it actually fits when printed.

## Questions I should be able to answer
1. *Why not let the LLM output the 3D model directly?* It can look right but have wrong dimensions or be unprintable. A schema makes failures checkable.
2. *What did `validate.py` find?* The box-based export is not watertight; the CadQuery export is.
3. *Why a 0.5 mm clearance?* Typical FDM tolerance is about 0.2-0.8 mm; the exact value should be tested with a print.
4. *What would you do next?* Screw bosses, collision checks on solids, a physical print test.
5. *What did the AI help with, and what did I do?* (Write your honest answer here.)

## Exercises (do at least two yourself, so the code is genuinely yours)
- Change `clearance` to 0.3 and re-run; note what changes.
- Add a third part (e.g. a sensor) to the spec and rebuild.
- Add one new check to `build()` in `enclosure.py`.
- Add a prompt to `eval/prompts.txt` and run the eval.
