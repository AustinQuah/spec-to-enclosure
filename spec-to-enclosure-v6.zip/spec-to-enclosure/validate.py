"""Check STL files: watertight? consistent winding? volume and size. Needs: pip install trimesh numpy
Usage: python validate.py out/tray.stl out_cq/tray.stl"""
import sys, trimesh
for f in sys.argv[1:]:
    m = trimesh.load(f)
    vol = f"{m.volume:.0f} mm3" if m.is_watertight else "n/a"
    print(f"{f}: watertight={m.is_watertight} winding_ok={m.is_winding_consistent} volume={vol} size={m.extents.round(1).tolist()}")
