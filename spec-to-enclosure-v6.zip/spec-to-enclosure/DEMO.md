# 3-minute demo script

1. **Problem (20s).** AI-generated shapes can look right but be unprintable. I separated creativity from precision.
2. **Live (60s).** Type an idea, generate the spec, build geometry, show the checks and the clearance numbers.
3. **Validation (30s).** `python validate.py`: the box-based export is not watertight; the CadQuery export is. This is why there are two backends.
4. **Evidence (30s).** First-pass vs after-repair success from `eval/results.csv`, plus `pytest` passing.
5. **Limits and next (30s).** No screw bosses or lid lip yet; USB cutout is fixed size; next is a physical print and checks on AI-generated meshes.

Do not claim: a physical print (unless done), eval numbers you haven't run, or code you can't explain.
