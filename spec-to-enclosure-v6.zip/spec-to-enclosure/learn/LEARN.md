# Rebuild it yourself: 8 short lessons

**How to use this:** type every snippet by hand (do not paste), in a new folder with a file per lesson. Before you run each one, write down what you *predict* it prints. Then run it. Then do the "Try" line. Finish a lesson only when you can explain each line out loud.

## Lesson 0: the Python you need here
```python
part = {"name": "ESP32", "w": 51.5}        # dict: named values
parts = [part, {"name": "OLED", "w": 27.5}] # list of dicts
for p in parts:                             # loop
    print(f"{p['name']} is {p['w']} mm wide")  # f-string
def double(n): return n * 2                 # function
```
Try: print the total width of all parts using a loop and a running `total = 0`.

## Lesson 1: a box is 12 triangles
A 3D model file stores surfaces as triangles. A box has 6 faces, each split into 2 triangles.
```python
def box(x0, y0, z0, x1, y1, z1):
    A, B, C, D = (x0, y0, z0), (x1, y0, z0), (x1, y1, z0), (x0, y1, z0)  # bottom corners
    E, F, G, H = (x0, y0, z1), (x1, y0, z1), (x1, y1, z1), (x0, y1, z1)  # top corners
    return [(A, D, C), (A, C, B), (E, F, G), (E, G, H), (A, B, F), (A, F, E),
            (C, D, H), (C, H, G), (D, A, E), (D, E, H), (B, C, G), (B, G, F)]
print(len(box(0, 0, 0, 10, 20, 5)))
```
Predict the number. Try: draw the box on paper and label A to H. The order of corners in each triangle (A, D, C) decides which way the face points; that is why it matches the real code.

## Lesson 2: layout is just a loop
```python
parts = [{"w": 51.5}, {"w": 27.5}]
wall, clearance = 2, 0.5
x = wall + clearance
positions = []
for p in parts:
    positions.append(x)
    x += p["w"] + 2 * clearance + 2     # part width + clearance both sides + 2 mm gap
print(positions)
print("outer width:", x - clearance - 2 + wall)
```
Predict both. Try: add a third part and check the width against your hand calculation.

## Lesson 3: cutting a hole by tiling
Without a CAD library you cannot "subtract". Instead, build the wall from pieces around the hole.
```python
def wall_with_hole(t, y0, y1, hy0, hy1, z0, z1, hz0, hz1):
    return [box(0, y0, z0, t, hy0, z1),     # left of hole
            box(0, hy1, z0, t, y1, z1),     # right of hole
            box(0, hy0, z0, t, hy1, hz0),   # below hole
            box(0, hy0, hz1, t, hy1, z1)]   # above hole
pieces = wall_with_hole(2, 2, 31.5, 11.75, 21.75, 2, 19, 5, 10)
print(len(pieces), sum(len(p) for p in pieces))
```
Predict both numbers. Try: change the hole position and sketch the four pieces. Weakness to remember: the pieces only touch, they are not merged (lesson 6 shows why this matters).

## Lesson 4: checks are (passed?, message) pairs
```python
def run_checks(wall, clearance):
    return [(wall >= 1.2, "wall at least 1.2 mm"),
            (0.2 <= clearance <= 0.8, "clearance in 0.2-0.8 mm")]
for ok, message in run_checks(1.0, 0.5):
    print("PASS" if ok else "FAIL", message)
```
Try: add a third check of your own. A list of pairs lets you print them, count the failures, or send the messages back to an LLM.

## Lesson 5: write an STL file
```python
def cross(u, v): return (u[1]*v[2]-u[2]*v[1], u[2]*v[0]-u[0]*v[2], u[0]*v[1]-u[1]*v[0])
def minus(a, b): return tuple(a[i] - b[i] for i in range(3))
def to_stl(triangles):
    lines = ["solid demo"]
    for a, b, c in triangles:
        n = cross(minus(b, a), minus(c, a))      # which way the triangle faces
        lines += ["facet normal %g %g %g" % n, "outer loop"]
        lines += ["vertex %g %g %g" % v for v in (a, b, c)]
        lines += ["endloop", "endfacet"]
    return "\n".join(lines + ["endsolid demo"])
open("box.stl", "w").write(to_stl(box(0, 0, 0, 10, 20, 5)))
```
Try: open `box.stl` in Blender (free) and confirm it is a 10 x 20 x 5 block.

## Lesson 6: validate with trimesh
```python
import trimesh      # pip install trimesh numpy
m = trimesh.load("box.stl")
print(m.is_watertight, m.volume)
```
Predict, then try loading the output of `enclosure.py` the same way. Watertight means every edge is shared by exactly two triangles, with no gaps. Touching boxes fail this; that is why the CadQuery backend exists.

## Lesson 7: boolean CAD with CadQuery
```python
import cadquery as cq      # pip install cadquery
shell = cq.Workplane("XY").box(87, 33.5, 19, centered=False)
cavity = cq.Workplane("XY").box(83, 29.5, 17, centered=False).translate((2, 2, 2))
tray = shell.cut(cavity)
cq.exporters.export(tray, "tray.stl")
```
Try: cut a 10 x 5 mm hole in one wall, then validate `tray.stl` like in lesson 6.

## Lesson 8: an LLM with a repair loop (no API key needed)
```python
def fake_llm(prompt):                      # pretend LLM: wrong first, right second
    return {"w": 70} if "problems" not in prompt else {"w": 51.5}
def check(spec): return [] if abs(spec["w"] - 51.5) < 1.5 else [f"w={spec['w']} but the board is 51.5"]
prompt = "an ESP32 box"
for attempt in range(3):
    spec = fake_llm(prompt); errs = check(spec)
    print(attempt, spec, errs)
    if not errs: break
    prompt = prompt + "\nproblems: " + "; ".join(errs)
```
Predict the three printed lines. This is the whole idea behind `pipeline.py`: feed the checker's complaints back to the model. Passing the LLM in as a function is what lets `tests/test_pipeline.py` run with no key.

## Final challenge
Close this repo. From these lessons alone, rebuild `enclosure.py` (layout, tray, lid, checks, STL) in one file, then compare with the real one. List every difference and explain which version you prefer and why.
