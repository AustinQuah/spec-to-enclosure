"""idea -> spec -> validate -> build, with a repair loop: any problems are fed back to the LLM."""
from enclosure import build
from specs import validate_spec, dim_mismatch

def problems(spec, ref):
    errs = validate_spec(spec)
    if errs:
        return errs
    return [m for ok, m in build(spec)["checks"] if not ok] + dim_mismatch(spec, ref)

def run(idea, ask, ref, max_repairs=2):
    """`ask(text)` must return a spec dict. Passing it in (instead of importing the LLM here)
    lets tests use a fake LLM with no API key."""
    prompt, log, spec = idea, [], None
    for _ in range(max_repairs + 1):
        try:
            spec = ask(prompt); errs = problems(spec, ref)
        except Exception as e:
            spec, errs = None, [f"could not parse the reply: {e}"]
        log.append(errs)
        if not errs:
            break
        prompt = idea + "\n\nYour previous spec had these problems:\n- " + "\n- ".join(errs) + "\nReturn a corrected spec as JSON only."
    return {"spec": spec, "problems": errs, "attempts": len(log), "first_pass_ok": not log[0], "ok": not errs}
