# Spec-to-Enclosure

Turn a plain-language hardware idea into a **printable enclosure**: an LLM writes a structured spec, deterministic code builds the geometry and checks it for printability.

```
idea --(LLM)--> spec JSON --(deterministic code)--> tray.stl + lid.stl + printability checks
```

The LLM never touches geometry. It only fills in a schema, so every failure is checkable and measurable.

## Quick start
- **Browser:** open `index.html` (or host it on GitHub Pages). Edit the spec, click *Build geometry*, rotate the 3D preview, save STLs. The "Generate spec with Claude" button only works inside claude.ai; elsewhere paste a spec.
- **CLI (no dependencies):** `python enclosure.py examples/weather_display.json out/`
- **LLM step:** `pip install anthropic`, set `ANTHROPIC_API_KEY`, then `python llm.py "a smart planter with a soil moisture screen"`

## Spec format (mm)
```json
{"wall":2,"clearance":0.5,"lid":2,
 "parts":[{"name":"ESP32 DevKit","w":51.5,"d":28.5,"h":13,"usb":true},
          {"name":"OLED 0.96in","w":27.5,"d":27.5,"h":4,"window":[22,11]}]}
```
Parts sit in a row. The first part with `usb` gets a 10x5 mm cutout in the -X wall; the first part with `window` gets a lid opening.

## Printability checks
Wall thickness (>= 1.2 mm), fit clearance (0.2-0.8 mm), USB part position, bed size (220x220x250), USB cutout fits the wall (the ~10 mm bridge above it is untested), window inside footprint. The lid prints face-down with no supports.

## Printer tolerance coupon
Clearance depends on your printer. `coupon.py` makes a plate with six slots (clearance 0.1 to 0.6 mm per side) and a test tab. Print both with the same settings as your enclosure, find the tightest slot the tab slides into with light finger pressure, and record it:
```
python coupon.py make out/
python coupon.py recommend 3 printer_profile.json
python coupon.py apply examples/weather_display.json printer_profile.json my_spec.json
```
This gives a per-printer clearance instead of a rule-of-thumb guess. Not yet validated on a physical print. Note: `coupon.stl` is built from touching boxes, so `validate.py` reports it as not watertight (the tab is fine); slicers usually repair this, and a CadQuery version is a good exercise.

## Tests
`pip install pytest trimesh numpy cadquery` then `pytest -q`. Tests cover layout dimensions, each check passing and failing, clearance numbers, triangle counts and watertightness of the CadQuery output. A GitHub Actions workflow runs them on every push (not yet run on GitHub).

## Evaluation
`python eval/run_eval.py` runs 12 prompts through idea -> spec -> validate -> build. If a spec has problems (bad schema, failed printability check, dimensions that disagree with `eval/datasheets.json` by more than 1.5 mm), the problems are sent back to the LLM for up to 2 repairs. It reports **first-pass success** and **success after repair**, so the value of the repair loop is measured. Results go to `eval/results.csv`.

**Results:** _fill in after running (first-pass ok __/12, ok after repair __/12)._

**What failed and what I changed:** _fill in._

## Known limitations
- `enclosure.py` builds the tray from touching boxes, not a boolean union. `validate.py` shows the result is **not watertight**; `cq_backend.py` fixes this with real CadQuery booleans (see below). No screw bosses or vents yet.
- Parts sit in a single row; no snap-fit lid lip, screw bosses or vents yet.
- Reference dimensions in `eval/datasheets.json` are approximate; verify against your own boards.
- Not yet validated by a physical print: _update when done_.

## Two geometry backends, measured
| Backend | File | `validate.py` result (default example) |
|---|---|---|
| Touching boxes (pure Python, no deps) | `enclosure.py` | watertight = **False** (tray and lid) |
| CadQuery boolean solids | `cq_backend.py` | watertight = **True**; tray 13,867 mm3 (with standoffs), lid 5,345 mm3; also exports STEP |

```
python enclosure.py examples/weather_display.json out
python cq_backend.py examples/weather_display.json out_cq
python validate.py out/tray.stl out_cq/tray.stl
```
Lesson: a model that looks right in a viewer can still be unprintable, so geometry needs automatic validation, not eyeballing.

## Roadmap
Screw bosses and lid screws, snap-fit lip, vent slots, multi-row layouts, part-to-part collision checks on the solids, per-part datasheet lookup, TypeScript API.

MIT licensed.
