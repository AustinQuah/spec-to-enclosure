# Application notes (edit so every line is TRUE for you)

Apply through the Indeed listing. Say: "Applying for Computational Geometry & CAD Engineering." Include:

**Project:** Spec-to-Enclosure, <GitHub link>. An LLM turns a device idea into a structured spec; code builds a printable tray and lid (plain-Python and CadQuery backends) and validates the result.

**My personal contribution:** <Fill honestly. For example: I designed the spec schema and the printability checks, verified the module dimensions against datasheets, wrote the evaluation set, and found that my first export was not watertight using a trimesh validator, which led me to add a CadQuery boolean backend. I used Claude as a coding assistant and I can walk through every file.>

**Result I measured:** <eval numbers once run>. Box backend: not watertight. CadQuery backend: watertight, with STEP export.

**Location:** Singapore. Open to San Francisco or remote from Singapore.
**Earliest start date:** <date>   **Weekly availability:** <hours>   **12-week commitment:** <yes/no, only if true>

**Honest self-description:** Civil engineering background (CAD/BIM experience in Revit and MicroStation); new to Python geometry libraries, learning fast; this project is my first from-scratch geometry pipeline.
