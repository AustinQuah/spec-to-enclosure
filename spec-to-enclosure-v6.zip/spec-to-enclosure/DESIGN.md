# Design rationale

**Problem.** AI-generated shapes can look right but be unmanufacturable (wrong internal dimensions, no room for parts, missing openings).

**Core decision.** Separate the fuzzy part from the precise part. An LLM fills a small JSON spec (the contract). Deterministic code builds geometry. Validators check it. Every failure is then checkable, debuggable and countable.

**Pipeline.** idea -> spec -> spec check vs reference dimensions -> layout -> geometry (tray, lid, port cut, window cut) -> validation -> export (STL, STEP).

**Repair loop.** `pipeline.py` sends any validation failures back to the LLM and retries up to twice. The LLM is passed in as a function, so tests use a fake LLM and need no API key. The eval reports first-pass vs after-repair success.

**Decisions and trade-offs.**
- Parts in one row: simple and predictable, limits layouts.
- Two backends: pure Python (no deps, runs in a browser) and CadQuery (real boolean solids, STEP).
- Separate validator: a model that looks right in a viewer can still be unprintable. `validate.py` showed the box-based export is not watertight; the CadQuery export is.
- Eval set with reference dimensions: turns "seems to work" into pass rates.

**Known simplifications (be upfront about these).**
- In the box backend parts float 3 mm above the floor; the CadQuery backend adds four 3 mm standoff posts under each part. No screw bosses yet.
- USB cutout size and height are fixed (10x5 mm), not read from the spec.
- The lid window is centred on the module, not on the real display's active area.
- Nothing holds the lid on yet (no lip or screws).
- Check thresholds (wall >= 1.2 mm, clearance 0.2-0.8 mm) are rules of thumb; a test print should confirm them.
- Reference dimensions in `eval/datasheets.json` are approximate.

**Calibration.** Clearance is printer-specific, so `coupon.py` generates a six-slot test coupon; the tightest slot that fits becomes the spec's clearance. Untested on a real print.

**Next steps.** Standoffs and screw bosses, snap-fit lip, collision checks on solids, physical print test, and applying the same checks to AI-generated meshes.
