"""Check a spec BEFORE building it: schema first, then reference dimensions."""

def _num(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool) and v > 0

def validate_spec(spec):
    """Return a list of problems (an empty list means the spec is usable)."""
    if not isinstance(spec, dict):
        return ["spec must be a JSON object"]
    errs = [f"'{k}' must be a positive number" for k in ("wall", "clearance", "lid") if not _num(spec.get(k))]
    parts = spec.get("parts")
    if not isinstance(parts, list) or not parts:
        return errs + ["'parts' must be a non-empty list"]
    for i, p in enumerate(parts):
        if not isinstance(p, dict):
            errs.append(f"part {i} must be an object"); continue
        name = p.get("name", f"part {i}")
        errs += [f"{name}: '{k}' must be a positive number (mm)" for k in ("w", "d", "h") if not _num(p.get(k))]
        win = p.get("window")
        if win is not None and not (isinstance(win, list) and len(win) == 2 and all(_num(v) for v in win)):
            errs.append(f"{name}: 'window' must be [width, height] in mm")
    if sum(1 for p in parts if isinstance(p, dict) and p.get("usb")) > 1:
        errs.append("only one part may have 'usb'")
    return errs

def dim_mismatch(spec, ref, tol=1.5):
    """Compare part sizes with known reference modules (matched by keyword in the part name)."""
    bad = []
    for p in spec["parts"]:
        for key, r in ref.items():
            if key.startswith("_") or key not in p["name"].lower():
                continue
            bad += [f"{p['name']} {k}={p[k]} but reference is {r[k]}" for k in ("w", "d", "h") if abs(p[k] - r[k]) > tol]
    return bad
