"""Printer tolerance coupon: find the clearance YOUR printer needs, then feed it back into the spec.

How it works: the coupon is a plate with 6 slots, each a little bigger than a small test tab
(slot 1 is the tightest). Print both, push the tab into each slot, and note the tightest slot
the tab slides into with light finger pressure. That slot's per-side clearance becomes your
`clearance` value.

  python coupon.py make out/                      -> out/coupon.stl, out/tab.stl
  python coupon.py recommend 3 printer_profile.json
  python coupon.py apply examples/weather_display.json printer_profile.json out_spec.json
"""
import copy, json, os, sys
from enclosure import box, stl

OFFSETS = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6]   # per-side clearance of slots 1..6, in mm

def make_coupon(tab_w=10.0, tab_l=12.0, thick=2.4, rib=4.0, offsets=OFFSETS):
    """Return the coupon plate and the test tab as triangle lists, plus slot sizes."""
    Y = tab_l + 2 * max(offsets) + 2 * rib
    plate, x, slots = [], 0.0, []
    b = lambda *v: box(plate, v)
    for c in offsets:
        sw, sl = tab_w + 2 * c, tab_l + 2 * c          # slot is bigger than the tab by c on every side
        y0 = (Y - sl) / 2
        b(x, 0, 0, x + rib, Y, thick); x += rib         # rib (solid wall) before the slot
        b(x, 0, 0, x + sw, y0, thick); b(x, y0 + sl, 0, x + sw, Y, thick)   # plate above/below the slot
        slots.append((round(sw, 2), round(sl, 2))); x += sw
    b(x, 0, 0, x + rib, Y, thick); x += rib             # final rib
    b(0.5, 0.5, thick, 3.5, 3.5, thick + 0.8)           # marker bump: slot 1 is on this side
    tab = []
    box(tab, (0, 0, 0, tab_w, tab_l, 6))
    return {"plate": plate, "tab": tab, "slots": slots, "size": (x, Y, thick)}

def recommend(slot, offsets=OFFSETS):
    """Slot number (1-based) -> per-side clearance in mm."""
    if not 1 <= slot <= len(offsets):
        raise ValueError(f"slot must be 1..{len(offsets)}")
    return offsets[slot - 1]

def apply_profile(spec, profile):
    """Return a copy of the spec with the printer's measured clearance."""
    s = copy.deepcopy(spec); s["clearance"] = profile["clearance"]; return s

if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else ""
    if cmd == "make":
        d = sys.argv[2] if len(sys.argv) > 2 else "out"
        r = make_coupon(); os.makedirs(d, exist_ok=True)
        open(f"{d}/coupon.stl", "w").write(stl("coupon", r["plate"]))
        open(f"{d}/tab.stl", "w").write(stl("tab", r["tab"]))
        print("Print BOTH files with the same material and settings as your enclosure.")
        for i, (sw, sl) in enumerate(r["slots"], 1):
            print(f"slot {i}: {sw} x {sl} mm  (clearance {OFFSETS[i-1]} mm per side)")
    elif cmd == "recommend":
        c = recommend(int(sys.argv[2])); out = sys.argv[3] if len(sys.argv) > 3 else "printer_profile.json"
        json.dump({"clearance": c, "slot": int(sys.argv[2]), "offsets": OFFSETS}, open(out, "w"), indent=1)
        print(f"clearance {c} mm per side -> {out}")
    elif cmd == "apply":
        s = apply_profile(json.load(open(sys.argv[2])), json.load(open(sys.argv[3])))
        json.dump(s, open(sys.argv[4], "w"), indent=1); print("wrote", sys.argv[4])
    else:
        print(__doc__)
