"""Idea -> spec JSON via the Anthropic API. Needs `pip install anthropic` and ANTHROPIC_API_KEY."""
import json, sys, anthropic
MODEL = "claude-sonnet-5-5"
PROMPT = ('Return ONLY JSON, no prose. Design the electronics layout for this device: "{idea}". '
 'Schema: {{"wall":2,"clearance":0.5,"lid":2,"parts":[{{"name":str,"w":mm,"d":mm,"h":mm (real module dimensions),'
 '"usb":true only on the microcontroller, which must be first,"window":[width,height] only on a display}}]}}. '
 'Use 2-4 real, common modules with realistic dimensions.')

def generate_spec(idea):
    m = anthropic.Anthropic().messages.create(model=MODEL, max_tokens=1000,
        messages=[{"role": "user", "content": PROMPT.format(idea=idea)}])
    t = m.content[0].text.strip().strip("`").removeprefix("json").strip()
    return json.loads(t)

if __name__ == "__main__":
    print(json.dumps(generate_spec(" ".join(sys.argv[1:])), indent=1))
