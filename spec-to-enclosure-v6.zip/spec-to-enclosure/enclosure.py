"""Spec -> printable enclosure (tray + lid) with printability checks. No dependencies.
Usage: python enclosure.py spec.json [out_dir]"""
import json, sys, os

def box(tris, b):
    x0, y0, z0, x1, y1, z1 = b
    if min(x1 - x0, y1 - y0, z1 - z0) < 1e-6:
        return
    A, B, C, D = (x0, y0, z0), (x1, y0, z0), (x1, y1, z0), (x0, y1, z0)
    E, F, G, H = (x0, y0, z1), (x1, y0, z1), (x1, y1, z1), (x0, y1, z1)
    tris += [(A, D, C), (A, C, B), (E, F, G), (E, G, H), (A, B, F), (A, F, E),
             (C, D, H), (C, H, G), (D, A, E), (D, E, H), (B, C, G), (B, G, F)]

def build(s):
    w, c, L, P = float(s["wall"]), float(s["clearance"]), float(s["lid"]), s["parts"]
    if not P:
        raise ValueError("no parts")
    for p in P:
        for k in ("w", "d", "h"):
            if not isinstance(p.get(k), (int, float)) or p[k] <= 0:
                raise ValueError(f"bad {k} on {p.get('name')}")
    cur, pos = w + c, []
    for p in P:
        pos.append(cur); cur += p["w"] + 2 * c + 2
    X = cur - c - 2 + w
    Y = max(p["d"] for p in P) + 2 * c + 2 * w
    H = max(p["h"] for p in P) + 2 * c + 3
    T, Ld, chk = [], [], []
    b = lambda a, *v: box(a, v)
    b(T, 0, 0, 0, X, Y, w); b(T, 0, 0, w, X, w, w + H)
    b(T, 0, Y - w, w, X, Y, w + H); b(T, X - w, w, w, X, Y - w, w + H)
    u = next((i for i, p in enumerate(P) if p.get("usb")), -1)
    hy, hz0 = Y / 2, w + 3
    if u >= 0:
        hz1 = hz0 + 5
        b(T, 0, w, w, w, hy - 5, w + H); b(T, 0, hy + 5, w, w, Y - w, w + H)
        b(T, 0, hy - 5, w, w, hy + 5, hz0); b(T, 0, hy - 5, hz1, w, hy + 5, w + H)
    else:
        b(T, 0, w, w, w, Y - w, w + H)
    wi = next((i for i, p in enumerate(P) if p.get("window")), -1)
    if wi >= 0:
        ww, wh = P[wi]["window"]
        cx = pos[wi] + P[wi]["w"] / 2
        x0, x1, y0, y1 = cx - ww / 2, cx + ww / 2, Y / 2 - wh / 2, Y / 2 + wh / 2
        b(Ld, 0, 0, 0, X, y0, L); b(Ld, 0, y1, 0, X, Y, L)
        b(Ld, 0, y0, 0, x0, y1, L); b(Ld, x1, y0, 0, X, y1, L)
        chk.append((ww <= P[wi]["w"] and wh <= P[wi]["d"], f"Lid window fits inside the {P[wi]['name']} footprint"))
    else:
        b(Ld, 0, 0, 0, X, Y, L)
    chk += [(w >= 1.2, f"Wall {w} mm >= 1.2 mm"),
            (0.2 <= c <= 0.8, f"Clearance {c} mm in 0.2-0.8 mm FDM range"),
            (u <= 0, "USB part is nearest the -X wall"),
            (X <= 220 and Y <= 220 and H + w + L <= 250, "Fits a 220x220x250 mm bed"),
            (u < 0 or 10 <= min(Y - 2 * w, H), "USB cutout 10x5 mm fits within the wall")]
    return {"tray": T, "lid": Ld, "X": X, "Y": Y, "H": H + w + L, "checks": chk}

def stl(name, tris):
    out = [f"solid {name}"]
    for a, b_, c_ in tris:
        u = [b_[i] - a[i] for i in range(3)]; v = [c_[i] - a[i] for i in range(3)]
        n = [u[1]*v[2]-u[2]*v[1], u[2]*v[0]-u[0]*v[2], u[0]*v[1]-u[1]*v[0]]
        l = sum(x*x for x in n) ** .5 or 1
        out.append("facet normal %g %g %g\nouter loop" % tuple(x / l for x in n))
        out += ["vertex %g %g %g" % t for t in (a, b_, c_)]
        out.append("endloop\nendfacet")
    return "\n".join(out + [f"endsolid {name}\n"])

def clearance_report(s):
    """Minimum gaps (mm) from parts to walls, lid and each other, computed from the layout."""
    w, c, P = float(s["wall"]), float(s["clearance"]), s["parts"]
    cur, pos = w + c, []
    for p in P:
        pos.append(cur); cur += p["w"] + 2 * c + 2
    X = cur - c - 2 + w
    Y = max(p["d"] for p in P) + 2 * c + 2 * w
    H = max(p["h"] for p in P) + 2 * c + 3
    return {"to_x_walls": min(pos[0] - w, (X - w) - (pos[-1] + P[-1]["w"])),
            "to_y_walls": min((Y - p["d"]) / 2 - w for p in P),
            "to_lid": min(H - 3 - p["h"] for p in P),
            "between_parts": min((pos[i + 1] - pos[i] - P[i]["w"] for i in range(len(P) - 1)), default=None)}

if __name__ == "__main__":
    r = build(json.load(open(sys.argv[1])))
    d = sys.argv[2] if len(sys.argv) > 2 else "out"
    os.makedirs(d, exist_ok=True)
    for n in ("tray", "lid"):
        open(f"{d}/{n}.stl", "w").write(stl(n, r[n]))
    print(f"Outer {r['X']:.1f} x {r['Y']:.1f} x {r['H']:.1f} mm -> {d}/tray.stl, {d}/lid.stl")
    for ok, m in r["checks"]:
        print("PASS" if ok else "FAIL", m)
    print("Clearances (mm):", {k: None if v is None else round(v, 2) for k, v in clearance_report(json.load(open(sys.argv[1]))).items()})
