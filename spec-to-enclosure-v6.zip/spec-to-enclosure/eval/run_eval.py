"""Run every prompt through idea -> spec -> checks, with and without the repair loop.
Usage: python eval/run_eval.py   (needs ANTHROPIC_API_KEY; writes eval/results.csv)"""
import csv, json, pathlib, sys
here = pathlib.Path(__file__).parent
sys.path.insert(0, str(here.parent))
from pipeline import run
from llm import generate_spec

ref = json.load(open(here / "datasheets.json"))
rows = []
for idea in [l.strip() for l in open(here / "prompts.txt") if l.strip()]:
    r = run(idea, generate_spec, ref)
    rows.append({"prompt": idea, "first_pass_ok": int(r["first_pass_ok"]), "ok_after_repair": int(r["ok"]),
                 "attempts": r["attempts"], "problems": "; ".join(r["problems"])})
    print(rows[-1])
with open(here / "results.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
n = len(rows)
print(f"\nfirst-pass ok {sum(r['first_pass_ok'] for r in rows)}/{n}   ok after repair {sum(r['ok_after_repair'] for r in rows)}/{n}")
