"""CadQuery backend: same spec as enclosure.py, but real boolean solids (clean, manifold STL).
Usage: python cq_backend.py spec.json [out_dir]   (needs: pip install cadquery)"""
import json, sys, os
import cadquery as cq

def build_cq(s):
    w, c, L, P = float(s["wall"]), float(s["clearance"]), float(s["lid"]), s["parts"]
    cur, pos = w + c, []
    for p in P:
        pos.append(cur); cur += p["w"] + 2 * c + 2
    X = cur - c - 2 + w
    Y = max(p["d"] for p in P) + 2 * c + 2 * w
    H = max(p["h"] for p in P) + 2 * c + 3
    box = lambda x, y, z: cq.Workplane("XY").box(x, y, z, centered=False)
    tray = box(X, Y, w + H).cut(box(X - 2 * w, Y - 2 * w, H).translate((w, w, w)))
    for i, p in enumerate(P):  # 3 mm standoff posts under each part's corners
        for x in (pos[i], pos[i] + p["w"] - 3):
            for y in (Y / 2 - p["d"] / 2, Y / 2 + p["d"] / 2 - 3):
                tray = tray.union(box(3, 3, 3).translate((x, y, w)))
    if any(p.get("usb") for p in P):  # 10 x 5 mm port cutout in the -X wall
        tray = tray.cut(box(w + 2, 10, 5).translate((-1, Y / 2 - 5, w + 3)))
    lid = box(X, Y, L)
    for i, p in enumerate(P):
        if p.get("window"):
            ww, wh = p["window"]
            lid = lid.cut(box(ww, wh, L + 2).translate((pos[i] + p["w"] / 2 - ww / 2, Y / 2 - wh / 2, -1)))
            break
    return tray, lid

if __name__ == "__main__":
    tray, lid = build_cq(json.load(open(sys.argv[1])))
    d = sys.argv[2] if len(sys.argv) > 2 else "out_cq"
    os.makedirs(d, exist_ok=True)
    cq.exporters.export(tray, f"{d}/tray.stl"); cq.exporters.export(lid, f"{d}/lid.stl")
    cq.exporters.export(tray, f"{d}/tray.step"); cq.exporters.export(lid, f"{d}/lid.step")
    print(f"wrote {d}/tray.stl, lid.stl and STEP files")
