import copy, json, pathlib, sys
ROOT = pathlib.Path(__file__).parent.parent
sys.path.insert(0, str(ROOT))
from pipeline import run
from specs import validate_spec
GOOD = json.load(open(ROOT / "examples" / "weather_display.json"))
REF = {"esp32": {"w": 51.5, "d": 28.5, "h": 13}}

def fake(replies):
    it, seen = iter(replies), []
    def ask(prompt):
        seen.append(prompt); r = next(it)
        if isinstance(r, Exception): raise r
        return r
    ask.seen = seen
    return ask

def bad_spec():
    s = copy.deepcopy(GOOD); s["parts"][0]["w"] = 70; return s

def test_good_spec_passes_first_time():
    r = run("idea", fake([GOOD]), REF)
    assert r["ok"] and r["first_pass_ok"] and r["attempts"] == 1

def test_repair_loop_fixes_wrong_dimensions():
    ask = fake([bad_spec(), GOOD]); r = run("idea", ask, REF)
    assert r["ok"] and not r["first_pass_ok"] and r["attempts"] == 2
    assert "ESP32 DevKit" in ask.seen[1]          # the problem text was sent back to the LLM

def test_gives_up_after_max_repairs():
    r = run("idea", fake([bad_spec()] * 3), REF, max_repairs=2)
    assert not r["ok"] and r["attempts"] == 3

def test_unparseable_reply_is_reported():
    r = run("idea", fake([ValueError("not json")]), REF, max_repairs=0)
    assert not r["ok"] and "could not parse" in r["problems"][0]

def test_validate_spec_names_the_bad_field():
    errs = validate_spec({"wall": 2, "clearance": 0.5, "lid": 2, "parts": [{"name": "A", "w": -1, "d": 5, "h": 5}]})
    assert any("'w'" in e for e in errs)
