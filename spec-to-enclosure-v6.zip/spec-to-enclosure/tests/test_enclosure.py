import copy, json, pathlib, sys
import pytest
ROOT = pathlib.Path(__file__).parent.parent
sys.path.insert(0, str(ROOT))
from enclosure import build, clearance_report
BASE = json.load(open(ROOT / "examples" / "weather_display.json"))

def spec(**kw):
    s = copy.deepcopy(BASE); s.update(kw); return s

def fails(s):
    return [m for ok, m in build(s)["checks"] if not ok]

def test_baseline_dimensions_and_checks():
    r = build(BASE)
    assert (r["X"], r["Y"], r["H"]) == pytest.approx((87.0, 33.5, 21.0))
    assert fails(BASE) == []

def test_smaller_clearance_shrinks_box():
    r = build(spec(clearance=0.3))
    assert (r["X"], r["Y"], r["H"]) == pytest.approx((86.2, 33.1, 20.6))

def test_large_clearance_fails_check():
    assert any("Clearance" in m for m in fails(spec(clearance=1.0)))

def test_thin_wall_fails_check():
    assert any("Wall" in m for m in fails(spec(wall=1.0)))

def test_third_part_widens_box():
    s = spec(); s["parts"].append({"name": "BME280 sensor", "w": 15, "d": 11, "h": 3})
    assert build(s)["X"] == pytest.approx(105.0) and fails(s) == []

def test_window_wider_than_module_fails():
    s = spec(); s["parts"][1]["window"] = [30, 11]
    assert any("window" in m.lower() for m in fails(s))

def test_clearance_report_baseline():
    c = clearance_report(BASE)
    assert c["to_x_walls"] == pytest.approx(0.5) and c["to_y_walls"] == pytest.approx(0.5)
    assert c["to_lid"] == pytest.approx(1.0) and c["between_parts"] == pytest.approx(3.0)

def test_triangle_counts():  # 12 triangles per box: tray = 8 boxes, lid = 4 boxes
    r = build(BASE)
    assert (len(r["tray"]), len(r["lid"])) == (96, 48)

def test_missing_key_raises():
    s = spec(); del s["wall"]
    with pytest.raises(KeyError):
        build(s)

def test_cadquery_output_is_watertight(tmp_path):
    cq = pytest.importorskip("cadquery"); trimesh = pytest.importorskip("trimesh")
    from cq_backend import build_cq
    tray, lid = build_cq(BASE)
    for n, solid in (("tray", tray), ("lid", lid)):
        cq.exporters.export(solid, str(tmp_path / f"{n}.stl"))
        assert trimesh.load(str(tmp_path / f"{n}.stl")).is_watertight
