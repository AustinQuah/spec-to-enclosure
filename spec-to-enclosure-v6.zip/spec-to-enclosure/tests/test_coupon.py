import json, pathlib, sys
import pytest
ROOT = pathlib.Path(__file__).parent.parent
sys.path.insert(0, str(ROOT))
from coupon import make_coupon, recommend, apply_profile
from enclosure import build
BASE = json.load(open(ROOT / "examples" / "weather_display.json"))

def test_slot_sizes_grow_by_two_clearances():
    widths = [w for w, _ in make_coupon()["slots"]]
    assert widths == pytest.approx([10.2, 10.4, 10.6, 10.8, 11.0, 11.2])

def test_coupon_size_and_triangle_count():
    r = make_coupon()
    assert r["size"] == pytest.approx((92.2, 21.2, 2.4))
    assert len(r["plate"]) == 20 * 12 and len(r["tab"]) == 12   # 20 boxes in the plate, 12 triangles each

def test_recommend_maps_slot_to_clearance():
    assert recommend(3) == pytest.approx(0.3)
    for bad in (0, 7):
        with pytest.raises(ValueError):
            recommend(bad)

def test_apply_profile_updates_copy_and_still_builds():
    out = apply_profile(BASE, {"clearance": 0.3})
    assert out["clearance"] == 0.3 and BASE["clearance"] == 0.5
    assert all(ok for ok, _ in build(out)["checks"])
